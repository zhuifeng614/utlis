###69. 购物车-删除
###70. 购物车-减少商品数量


###71. 购物车-订单确认页面

在订单确认页面中，需要完成2项功能，分别是“列出当前用户所有的收货地址”，“列出用户在前序页面中选择的购物车记录的列表”

“列出当前用户所有的收货地址”在之前的功能中已经实现了，现在页面只要直接请求`/addresses/list`，即可获取该用户的所有收获地址数据，在页面上通过js动态显示出来


“列出用户在前序页面中选择的购物车记录”属于一次查询操作，根据用户选中的购物车记录的cid，查询相关数据：

	select * from t_cart left join t_product on t_cart.pid= t_parduce.id where cid in [?,?,?]

在`CartMapper.java`接口中声明对应的抽象方法：

	List<CartVO> findByCids(Integer[] cids);

分析发现，在返回列表时，应该对数据的归属进行验证，仅返回当前用户对应的列表数据，因此，在查询时，需要获取购物车数据对应的uid信息。之前使用的`CartVO`中没有uid字段，因此在这里添加`uid`字段，并添加必要的方法(GET/SET/toString)

在`CartMapper.xml`中配置对应的映射：

	<!-- 根据一组cid查询对应的购物车记录 -->
	<!-- List<CartVO> findByCids(Integer[] cids) -->
	<select id="findByCids"
		resultType="cn.tedu.store.entity.CartVO">
		select  
			t1.cid, t1.pid, 
			t2.image, t2.title, 
			t2.price as realPrice, t1.price, 
			t1.num, t1.uid
		from 
			t_cart t1 left join t_product t2
		on
			t1.pid = t2.id
		where
			cid in
			<foreach collection="array"
				item="cid" separator=","
				open="(" close=")"
			>
 				#{cid}
			</foreach>
		order by
			t1.modified_time desc;
	</select>

开发对应的测试方法：

	@Test
	public void findByCids() {
		Integer[] cids= {4,9};
		List<CartVO> list=mapper.findByCids(cids);
		for(CartVO vo:list) {
			System.err.println(vo);
		}
	}

在`ICartService`中添加对应的抽象方法：


	List<CartVO> getByCids(Integer[] cids,Integer uid);

在`CartServiceImpl`中添加持久层方法的私有实现：

	/**
	 *  根据一组cid查询对应的购物车记录
	 * @param cids 一组购物车记录的id
	 * @return 购物车记录数据
	 */
	private List<CartVO> findByCids(Integer[] cids){
		return mapper.findByCids(cids);
	}

在`CartServiceImpl`中实现该方法：

	@Override
	public List<CartVO> getByCids(Integer[] cids, Integer uid) {
		// 参数判断
		if(cids==null) {
			return new ArrayList<CartVO>();
		}
		
		List<CartVO> result=findByCids(cids);
		// 仅返回参数uid对应的数据
		Iterator<CartVO> it=result.iterator();
		while(it.hasNext()) {
			CartVO vo=it.next();
			if(!vo.getUid().equals(uid)) {
				// 删除与参数uid不一致的购物车记录
				it.remove();
			}
		}
		return result;
	}

添加必要的测试：

	@Test
	public void getByCids() {
		Integer[] cids= {9,10,11};
		List<CartVO> list=service.getByCids(cids, 1);
		for(CartVO vo:list) {
			System.err.println(vo);
		}
	}


在`CartController`中添加如下方法：

	@GetMapping("get_by_cids")
	public JsonResult<List<CartVO>> getByCids(Integer[] cids, HttpSession session){
		Integer uid=getUidFromSession(session);
		
		List<CartVO> data=service.getByCids(cids,uid);
		return new JsonResult<>(SUCCESS,data);
	}

在浏览器通过`localhost:8080/carts/get_by_cids?cids=9&cids=10&cids=11`进行测试


在`orderConfirm.html`中添加展示购物车数据列表的逻辑

###72. 订单-功能分析

订单相关功能的数据库表设计：

`order_time`：下单时间，即该订单的创建时间，可以用于计算该订单的有效期，在有效期内必须支付，并且有效期内会锁定该订单涉及的商品的库存。如果订单在有效期内未支付，则释放锁定的库存。

`pay_time`：订单的支付时间，主要是给用户对账使用的

创建`t_order`表：

	CREATE TABLE t_order(
		id INT AUTO_INCREMENT COMMENT 'id',
		uid INT COMMENT '用户id',
		recv_name VARCHAR(50) COMMENT '收件人姓名',
		recv_phone VARCHAR(30) COMMENT '收件人电话',
		recv_province VARCHAR(50) COMMENT '收货省',
		recv_city VARCHAR(50) COMMENT '收货市',
		recv_area VARCHAR(50) COMMENT '收货区',
		recv_address VARCHAR(50) COMMENT '详细地址',
		status INT COMMENT '订单状态，0-未支付 1-已支付',
		price BIGINT COMMENT '订单总价',
		order_time DATETIME COMMENT '订单创建时间',
		pay_time DATETIME COMMENT '订单支付时间',
		created_user VARCHAR(50) COMMENT '创建用户',
		created_time DATETIME COMMENT '创建时间',
		modified_user VARCHAR(50) COMMENT '最后修改用户',
		modified_time DATETIME COMMENT '最后修改时间',
		PRIMARY KEY (id)
	)DEFAULT CHARSET=utf8;


创建`t_order_item`表：

	CREATE TABLE t_order_item(
		id INT AUTO_INCREMENT COMMENT 'id',
		oid INT COMMENT '订单id',
		pid INT COMMENT '商品id',
		num INT COMMENT '商品数量',
		price BIGINT COMMENT '商品单价',
		image VARCHAR(100) COMMENT '商品图片路径',
		title VARCHAR(100) COMMENT '商品标题',
		created_user VARCHAR(50) COMMENT '创建用户',
		created_time DATETIME COMMENT '创建时间',
		modified_user VARCHAR(50) COMMENT '最后修改用户',
		modified_time DATETIME COMMENT '最后修改时间',
		PRIMARY KEY (id)
	)DEFAULT CHARSET=utf8;


###73. 订单-创建实体类:`Order`, `OrderItem`

创建`cn.tedu.store.entity.Order`，继承`BaseEntity`：

创建`cn.tedu.store.entity.OrderItem`，继承`BaseEntity`：



###74. 订单-创建-持久层：

规划SQL语句：

	insert into t_order (除id外所有字段) values(对应的值)

	insert into t_order_item (除id外所有字段) values(对应的值)

创建`cn.tedu.store.mapper.OrderMapper`一个接口即可,并添加以下2个抽象方法：

	Integer saveOrder(Order order);

	Integer saveOrderItem(OrderItem item);

在`OrderMapper.xml`中配置对应的映射：


###75. 订单-创建-业务层：


订单-添加-控制器层：


订单-添加-前端界面：



### -----------------
### API
别人写好的方法

### API 文档
别人写好的代码的注释和说明

### 面试中问到项目，该如何准备：

1. 介绍以下你写过什么项目？


2. 你具体写了什么功能？
	介绍你自己写的功能：注册、登录、添加购物车、添加收获地址

3. 说一下添加购物车的逻辑：

	从前往后说：
		用户点击添加地址按钮，返回一个添加地址的表单，输入信息后提交AddressController，调用AddressService，再调AddressMapper将数据存入数据库。
		在AddressService中，需要先进行一些判断...，还需要从省市区信息中，根据前台传来的code，获取对应的名称，补充到实体类中，再执行添加。

	表单中的code是哪来的？
		页面有一个就绪事件，通过AJAX向后台请求所有省级的名称和编号，动态生成下拉列表中的省级内容。
		同时，为省的`<select>`添加了一个change事件，当用户选择一个省时，自动发AJAX请求对应的市级列表，逻辑和省一样。


4. 如果遇到不会的问题：

	1. 很复杂的组件 Spring Cloud 没用过

	2. 简单的零碎的知识点：AJAX发请求不使用缓存，遇到之后回来记住，查，学，下次就会了












