package cn.tedu.store.service;

/**
 * 订单及订单项的业务层接口
 */
public interface IOrderService {
	
	/**
	 * 创建一个订单及相应的订单项数据的方法
	 * @param aid 收货地址id
	 * @param cids 一组购物车记录id
	 * @param uid 用户id
	 * @param username 操作人名称
	 */
	void createOrder(Integer aid,
			Integer[] cids, 
			Integer uid,
			String username);
	

}
