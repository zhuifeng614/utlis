package cn.tedu.store.mapper;

import java.util.List;

import cn.tedu.store.entity.Order;
import cn.tedu.store.entity.OrderItem;

/**
 * 订单数据和订单项数据的持久层接口
 */
public interface OrderMapper {
	
	/**
	 * 保存一条订单数据
	 * @param order 订单数据
	 * @return 受影响的行数
	 */
	Integer saveOrder(Order order);

	/**
	 * 保存一条订单项数据
	 * @param item 订单项数据
	 * @return 受影响的行数
	 */
	Integer saveOrderItem(OrderItem item);
	
	
	/**
	 * 保存多条订单项数据
	 * @param list 订单项数据的集合
	 * @return 受影响的行数
	 */
	Integer saveOrderItems(List<OrderItem> list);
	
	
	

}
