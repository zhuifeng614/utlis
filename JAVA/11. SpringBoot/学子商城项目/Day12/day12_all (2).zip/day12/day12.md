###72. 订单-功能分析

订单相关功能的数据库表设计：

`order_time`：下单时间，即该订单的创建时间，可以用于计算该订单的有效期，在有效期内必须支付，并且有效期内会锁定该订单涉及的商品的库存。如果订单在有效期内未支付，则释放锁定的库存。

`pay_time`：订单的支付时间，主要是给用户对账使用的

创建`t_order`表：

	CREATE TABLE t_order(
		id INT AUTO_INCREMENT COMMENT 'id',
		uid INT COMMENT '用户id',
		recv_name VARCHAR(50) COMMENT '收件人姓名',
		recv_phone VARCHAR(30) COMMENT '收件人电话',
		recv_province VARCHAR(50) COMMENT '收货省',
		recv_city VARCHAR(50) COMMENT '收货市',
		recv_area VARCHAR(50) COMMENT '收货区',
		recv_address VARCHAR(50) COMMENT '详细地址',
		status INT COMMENT '订单状态，0-未支付 1-已支付',
		price BIGINT COMMENT '订单总价',
		order_time DATETIME COMMENT '订单创建时间',
		pay_time DATETIME COMMENT '订单支付时间',
		created_user VARCHAR(50) COMMENT '创建用户',
		created_time DATETIME COMMENT '创建时间',
		modified_user VARCHAR(50) COMMENT '最后修改用户',
		modified_time DATETIME COMMENT '最后修改时间',
		PRIMARY KEY (id)
	)DEFAULT CHARSET=utf8;


创建`t_order_item`表：

	CREATE TABLE t_order_item(
		id INT AUTO_INCREMENT COMMENT 'id',
		oid INT COMMENT '订单id',
		pid INT COMMENT '商品id',
		num INT COMMENT '商品数量',
		price BIGINT COMMENT '商品单价',
		image VARCHAR(100) COMMENT '商品图片路径',
		title VARCHAR(100) COMMENT '商品标题',
		created_user VARCHAR(50) COMMENT '创建用户',
		created_time DATETIME COMMENT '创建时间',
		modified_user VARCHAR(50) COMMENT '最后修改用户',
		modified_time DATETIME COMMENT '最后修改时间',
		PRIMARY KEY (id)
	)DEFAULT CHARSET=utf8;


###73. 订单-创建实体类:`Order`, `OrderItem`

创建`cn.tedu.store.entity.Order`，继承`BaseEntity`：

	public class Order extends BaseEntity {

		private static final long serialVersionUID = 1L;
		private Integer id;
		private Integer uid;
		private String recvName;
		private String recvPhone;
		private String recvProvince;
		private String recvCity;
		private String recvArea;
		private String recvAddress;
		private Integer status;
		private Long price;
		private Date orderTime;
		private Date payTime;
		// GET/SET/基于id生成hashcode和equals/toString
	}

创建`cn.tedu.store.entity.OrderItem`，继承`BaseEntity`：

	public class OrderItem extends BaseEntity{
	
		private static final long serialVersionUID = 1L;
		private Integer id;
		private Integer oid;
		private Integer pid;
		private Integer num;
		private Long price;
		private String image;
		private String title;
		// GET/SET/基于id生成hashcode和equals/toString

	}


###74. 订单-创建-持久层：

规划SQL语句：

	insert into t_order (除id外所有字段) values(对应的值)

	insert into t_order_item (除id外所有字段) values(对应的值)

创建`cn.tedu.store.mapper.OrderMapper`一个接口即可,并添加以下2个抽象方法：

	/**
	 * 保存一条订单数据
	 * @param order 订单数据
	 * @return 受影响的行数
	 */
	Integer saveOrder(Order order);

	/**
	 * 保存一条订单项数据
	 * @param item 订单项数据
	 * @return 受影响的行数
	 */
	Integer saveOrderItem(OrderItem item);

在`OrderMapper.xml`中配置对应的映射：

	<!-- 保存一条订单数据 -->
	<!-- Integer saveOrder(Order order) -->
	<insert id="saveOrder"
		useGeneratedKeys="true"
		keyProperty="id">
		INSERT INTO
			t_order(
			uid,recv_name,
			recv_phone,recv_province,
			recv_city,recv_area,
			recv_address,status,
			price,order_time,
			pay_time,
			created_user, created_time,
			modified_user, modified_time
			)
		VALUES(
			#{uid},#{recvName},
			#{recvPhone},#{recvProvince},
			#{recvCity},#{recvArea},
			#{recvAddress},#{status},
			#{price},#{orderTime},
			#{payTime},
			#{createdUser}, #{createdTime},
			#{modifiedUser}, #{modifiedTime}
		)
	</insert>
	
	
	<!-- 保存一条订单项数据 -->
	<!-- Integer saveOrderItem(OrderItem item) -->
	<insert id="saveOrderItem"
		useGeneratedKeys="true"
		keyProperty="id">
		INSERT INTO
			t_order_item(
			oid,pid,
			num,price,
			image,title,
			created_user, created_time,
			modified_user, modified_time
			)
		VALUES(
			#{oid},#{pid},
			#{num},#{price},
			#{image},#{title},
			#{createdUser}, #{createdTime},
			#{modifiedUser}, #{modifiedTime}
		)
	</insert>

在`OrderMapperTests`中开发对应的测试用例：

	@Autowired
	OrderMapper mapper;

	@Test
	public void saveOrder() {
		Order order=new Order();
		order.setPrice(1000L);
		order.setRecvName("Tom");
		System.err.println("before:"+order.getId());
		Integer row=mapper.saveOrder(order);
		System.err.println("row="+row);
		System.err.println("after:"+order.getId());
		
	}
	
	@Test
	public void saveOrderItem() {
		OrderItem item=new OrderItem();
		item.setPid(111);
		item.setOid(2);
		item.setPrice(2000L);
		Integer row=mapper.saveOrderItem(item);
		System.err.println("row="+row);
	}


###75. 订单-创建-业务层：

**(a) 规划异常**

`InsertException`，`CartNotFoundException`,`AddressNotFoundException`

**(b) 接口和抽象方法**

创建`cn.tedu.store.service.IOrderService`接口，添加以下抽象方法：

	void createOrder(Integer aid,Integer[] cids, Integer uid,String username);

**(c) 实现抽象方法**

在实现业务中，需要使用`aid`查询收获地址数据，因此，需要在`IAddressService`中添加抽象方法：

	/**
	 * 根据收货地址id获取收获地址数据
	 * @param aid 收货地址id
	 * @return 收获地址数据
	 */
	Address getByAid(Integer aid);

在`AddressServiceImpl`中实现该抽象方法：

	@Override
	public Address getByAid(Integer aid) {
		return findByAid(aid);
	};


创建`cn.tedu.store.service.impl.OrderServiceImpl`类，继承`IOrderService`接口，添加`@Autowired OrderMapper mapper`,`@Autowired IAddressService addressService`,`@Autowired ICartService cartService`

添加持久层2个抽象方法的私有实现：

	/**
	 * 保存一条订单数据
	 * @param order 订单数据
	 * @return 受影响的行数
	 */
	private void saveOrder(Order order) throws InsertException {
		Integer row=mapper.saveOrder(order);
		if(row!=1) {
			throw new InsertException("创建订单记录异常！插入订单数据异常！");
		}
	}

	/**
	 * 保存一条订单项数据
	 * @param item 订单项数据
	 * @return 受影响的行数
	 */
	private void saveOrderItem(OrderItem item) throws InsertException{
		Integer row=mapper.saveOrderItem(item);
		if(row!=1) {
			throw new InsertException("创建订单记录异常！插入订单项数据异常！");
		}
	}


实现接口中定义的抽象方法：

	@Transactional
	public void createOrder(Integer aid,Integer[] cids, Integer uid,String username){
		// 创建当前时间的对象 now

		// 根据cids查询对应的CartVO的集合
		// 判断结果集合的长度是否为0
		// 是：CartNotFoundException

		// 计算totalPrice

		// 创建一个Order对象
		// 补充uid
		// 根据aid查询收获地址数据
		// 判断结果是否为null
		// 是：AddressNotFoundException

		// 补充recv*数据
		// 补充status -> 0
		// 补充price -> 总价，在上面已经计算过
		// 补充orderTime -> now
		// 补充4项日志数据
		// 添加订单数据


		// 遍历上面查到的CartVO的集合
		//-- 创建一个OrderItem对象
		//-- 补充 oid
		//-- 补充 pid,num,price,image,titel
		//-- 补充 4项日志数据
		//-- 添加一个OrderItem数据

		// 未完，待续

		// 1. 清除对应的购物车数据 真删除
		// 2. 销库存：从t_product中减少对应的商品数量
		// 3. 启动计时器 15分钟 之后检查订单是否未支付
		// 是：将该订单状态修改为已取消，同时将扣除的商品数量再加回去
	}

代码实现如下：

	@Autowired
	OrderMapper mapper;
	
	@Autowired
	IAddressService addressService;
	
	@Autowired
	ICartService cartService;
	
	@Override
	public void createOrder(Integer aid, Integer[] cids, Integer uid, String username) 
		throws InsertException,CartNotFoundException,AddressNotFoundException {
		// 创建当前时间的对象 now
		Date now=new Date();

		// 根据cids查询对应的CartVO的集合
		List<CartVO> cartVOs=cartService.getByCids(cids, uid);
		// 判断结果集合的长度是否为0
		if(cartVOs.size()==0) {
			// 是：CartNotFoundException
			throw new CartNotFoundException("创建订单记录异常！未找到相关购物车记录");
		}

		// 计算totalPrice
		Long totalPrice=0L;
		for(CartVO vo:cartVOs) {
			totalPrice+=(vo.getRealPrice()*vo.getNum());
		}

		// 创建一个Order对象
		Order order=new Order();
		// 补充uid
		order.setUid(uid);
		// 根据aid查询收获地址数据
		Address address=addressService.getByAid(aid);
		// 判断结果是否为null
		if(address==null) {
			// 是：AddressNotFoundException
			throw new AddressNotFoundException("创建订单记录异常！未查到对应的收货地址！");
		}

		// 补充recv*数据
		order.setRecvName(address.getName());
		order.setRecvPhone(address.getPhone());
		order.setRecvProvince(address.getProvinceName());
		order.setRecvCity(address.getCityName());
		order.setRecvArea(address.getAreaName());
		order.setRecvAddress(address.getAddress());
		// 补充status -> 0 未支付 1 已支付 2已取消 
		order.setStatus(0);
		// 补充price -> 总价，在上面已经计算过
		order.setPrice(totalPrice);
		// 补充orderTime -> now
		order.setOrderTime(now);
		// 补充4项日志数据
		order.setCreatedUser(username);
		order.setCreatedTime(now);
		order.setModifiedUser(username);
		order.setModifiedTime(now);
		// 添加订单数据
		saveOrder(order);

		List<Integer> list=new ArrayList();

		// 遍历上面查到的CartVO的集合
		for(CartVO vo:cartVOs) {
			list.add(vo.getCid());

			//-- 创建一个OrderItem对象
			OrderItem item=new OrderItem();
			//-- 补充 oid
			item.setOid(order.getId());
			//-- 补充 pid,num,price,image,titel
			item.setPid(vo.getPid());
			item.setNum(vo.getNum());
			item.setPrice(vo.getRealPrice());
			item.setImage(vo.getImage());
			item.setTitle(vo.getTitle());
			//-- 补充 4项日志数据
			item.setCreatedUser(username);
			item.setCreatedTime(now);
			item.setModifiedUser(username);
			item.setModifiedTime(now);
			//-- 添加一个OrderItem数据
			saveOrderItem(item);
		}

		// 未完，待续

		cartService.removeByCids(list);



	}

开发对应的测试用例：

	@Autowired
	IOrderService service;
	
	@Test
	public void createOrder() {
		try {
			Integer[] cids= {9,10};
			service.createOrder(16, cids, 1, "管理员");
		} catch (Exception e) {
			System.err.println(e.getClass().getName());
			System.err.println(e.getMessage());
		}
	}

###75. 订单-创建-业务层-删除购物车记录：

在订单生成成功后，应该删除订单项对应的购物车记录，使用真删除，对应的SQL语句大概是：cids

	delete from t_cart where cid in (?,?,?);

因此，需要在`CartMapper.java`接口中添加抽象方法：

	Integer deleteByCids(Integer[] cids);

之后，在`CartMapper.xml`中配置对应的映射：


在`CartMapperTests`中开发对应的测试用例：


之后，在`ICartService`接口中添加对应的业务层抽象方法：

	void removeByCids(Integer[] cids, Integer uid);

之后，在`CartServiceImpl`中：

添加持久层抽象方法的私有实现：

	/**
	 * 根据一组cid删除对应的购物车记录
	 * @param cids 一组购物车id
	 * @return 受影响的行数
	 */
	private void deleteByCids(Integer[] cids)throws DeleteException {
		if(cids==null || cids.length==0) {
			throw new IllegalArgumentException("删除购物车记录异常！参数异常！");
		}
		
		Integer rows=mapper.deleteByCids(cids);
		if(rows<1) {
			throw new DeleteException("删除购物车记录异常！请联系管理员");
		}
	}

实现接口中定义的抽象方法：

	public void removeByCids(Integer[] cids, Integer uid){
		// 需要验证cids的正确性
		// 判断cids是否为null

		// 需要验证数据的归属性

		// 执行删除操作
		deleteByCids(cids);
	}

代码实现如下：

	@Override
	public void removeByCids(Integer[] cids, Integer uid) {
		// 验证cids的正确性
		if(cids==null) {
			throw new IllegalArgumentException("参数异常");
		}
		List<CartVO> cartVOs=findByCids(cids);
		if(cartVOs==null || cartVOs.size()==0) {
			throw new CartNotFoundException("删除购物车记录异常！未找到对应记录");
		}
		
		// 验证数据的归属性
		// 用于保存正确的cid的集合
		List<Integer> rightCids=new ArrayList<Integer>();
		
		// 遍历，筛选出当前用户有权限操作的cid
		for(CartVO vo:cartVOs) {
			if(vo.getUid().equals(uid)) {
				rightCids.add(vo.getCid());
			}
		}
		
		// 执行删除操作
		deleteByCids(rightCids.toArray(new Integer[rightCids.size()]));
	}

在`CartServiceTests`中开发对应的测试用例：

	@Test
	public void removeByCids() {
		try {
			Integer[] cids= {14,15};
			service.removeByCids(cids, 2);
		}catch(Exception e) {
			System.err.println(e.getClass().getName());
			System.err.println(e.getMessage());
		}
	}

###76. 订单-创建-业务层-销库存：

销库存指的是在订单创建成功后，将订单项中的商品数量从商品表的库存数量中减出来，所以大概的SQL语句：

	update t_produce set num=? where id=?;

在更新商品库存数量之前，应该对商品数据是否存在，以及库存更新后是否充足进行验证，相当于需要使用pid去查商品对应的数据，该持久层方法之前已经实现过。

在`ProductMapper.java`接口中添加以下抽象方法：

	Integer updateNum(
			@Param("num") Integer num,
			@Param("id") Integer id);

在`ProductMapper.xml`中配置对应的映射：


在`ProductMapperTests`中开发对应的测试用例：

规划业务层异常：

	`ProductNotFoundException`
	`ProductOutOfStockException`
	`UpdateException`

在`IProductService`接口中添加抽象方法：

	void reduceNum(Integer pid, Integer num);

在`ProductServiceImpl`中:

添加持久层抽象方法的私有实现：

	private void updateNum(Integer num,
			Integer id){
		Integer row=mapper.updateNum(num,id);
		if(){
			....
		}
	}

实现业务层声明的抽象方法：

	public void reduceNum(Integer pid, Integer num){
		// 根据pid查询商品数据
		// 判断结果是否为null
		// 是：ProductNotFoundException

		// 从查询结果中获取当前库存量
		// 计算库存减少后的结果
		// 判断该结果是否小于0
		// 是：ProductOutOfStockException

		// 执行更新操作
	}

开发对应的测试用例：


在`OrderServiceImpl`中的`createOrder()`方法中，补充“销库存”的逻辑，并进行验证：