###76. 订单-创建-业务层-销库存：

销库存指的是在订单创建成功后，将订单项中的商品数量从商品表的库存数量中减出来，所以大概的SQL语句：

	update t_product set num=? where id=?;

在更新商品库存数量之前，应该对商品数据是否存在，以及库存更新后是否充足进行验证，相当于需要使用pid去查商品对应的数据，该持久层方法之前已经实现过。

在`ProductMapper.java`接口中添加以下抽象方法：

	Integer updateNum(
			@Param("num") Integer num,
			@Param("id") Integer id);

在`ProductMapper.xml`中配置对应的映射：

	<!-- 更新一个商品的库存数量 -->
	<!-- Integer updateNum(
			@Param("num") Integer num,
			@Param("id") Integer id) -->
	<update id="updateNum">
		update 
			t_product 
		set 
			num=#{num} 
		where 
			id=#{id}
	</update>


在`ProductMapperTests`中开发对应的测试用例：

规划业务层异常：

	`ProductNotFoundException`
	`ProductOutOfStockException`
	`UpdateException`

在`IProductService`接口中添加抽象方法：

	void reduceNum(Integer pid, Integer num);

在`ProductServiceImpl`中:

添加持久层抽象方法的私有实现：

	/**
	 *  更新一个商品的库存数量
	 * @param num 新的库存数量
	 * @param id 商品的id
	 * @return
	 */
	private void updateNum(Integer num,Integer id) throws UpdateException {
		Integer row=mapper.updateNum(num, id);
		if(row!=1) {
			throw new UpdateException("更新商品库存数量失败！更新异常！");
		}
	}

实现业务层声明的抽象方法：

	public void reduceNum(Integer pid, Integer num){
		// 根据pid查询商品数据
		// 判断结果是否为null
		// 是：ProductNotFoundException

		// 从查询结果中获取当前库存量
		// 计算库存减少后的结果
		// 判断该结果是否小于0
		// 是：ProductOutOfStockException

		// 执行更新操作
	}

具体实现如下：

	@Override
	public void reduceNum(Integer pid, Integer num) {
		// 根据pid查询商品数据
		Product product=findById(pid);
		// 判断结果是否为null
		if(product==null) {
			// 是：ProductNotFoundException
			throw new ProductNotFoundException("减少商品库存数量异常！商品数据不存在！");
		}

		// 从查询结果中获取当前库存量
		Integer oldNum=product.getNum();
		// 计算库存减少后的结果
		Integer newNum=oldNum-num;
		// 判断该结果是否小于0
		if(newNum<0) {
			// 是：ProductOutOfStockException
			throw new ProductOutOfStockException("减少商品库存数量异常！商品库存不足！");
		}

		// 执行更新操作
		updateNum(newNum, pid);
	}

开发对应的测试用例：

	@Test
	public void reduceNum() {
		try {
			service.reduceNum(10000001, 51);
		} catch (ServiceException e) {
			System.err.println(e.getClass().getName());
			System.err.println(e.getMessage());
		}
	}


在`OrderServiceImpl`中的`createOrder()`方法中，补充“销库存”的逻辑，并进行验证：

	// 销库存
	productService.reduceNum(vo.getPid(), vo.getNum());


###77. 订单-创建-业务层-处理超时未支付：

如果一个订单在创建后的规定时间内(15分钟)没有支付，即订单数据的`status`为0，需要进行两项处理，分别是“修改订单状态 3”，订单状态(0-未支付 1-已支付 2-取消 3-超时)，同时应该“归还库存”。


“修改订单状态”是一个更新操作，SQL语句大概是：

	update t_order set status=?,modified_user=?, modified_time=? where id=?

在更新之间，应该使用订单id查询订单状态：

	select * from t_order where id=?

需要在`OrderMapper.java`接口中添加以上两项操作对应的抽象方法：

	Integer updateStatus(
		@Param("id") Integer id,
		@Param("status") Integer status,
		@Param("username") String username,
		@Param("modifiedTime") Date modifiedTime);

	Order findById(Integer id);


需要在`OrderMapper.xml`中配置对应的映射：

	<resultMap id="OrderEntityMap" 
		type="cn.tedu.store.entity.Order" >
		<id column="id"  property="id"/>
		<result column="uid" property="uid"/>
		<result column="recv_name" property="recvName"/>
		<result column="recv_phone" property="recvPhone"/>
		<result column="recv_province" property="recvProvince"/>
		<result column="recv_city" property="recvCity"/>
		<result column="recv_area" property="recvArea"/>
		<result column="recv_address" property="recvAddress"/>
		<result column="status" property="status"/>
		<result column="price" property="price"/>
		<result column="order_time" property="orderTime"/>
		<result column="pay_time" property="payTime"/>
		<result column="created_user" property="createdUser" />
		<result column="created_time" property="createdTime" />
		<result column="modified_user" property="modifiedUser" />
		<result column="modified_time" property="modifiedTime" />
	</resultMap>

	<!-- 更新订单状态 -->
	<!-- Integer updateStatus(
			@Param("id") Integer id,
			@Param("status") Integer status,
			@Param("username") String username,
			@Param("modifiedTime") Date modifiedTime) -->
	<update id="updateStatus">
		update 
			t_order 
		set 
			status=#{status}, 
			modified_user=#{username}, 
			modified_time=#{modifiedTime} 
		where 
			id=#{id}
	</update>
	
	<!-- 根据id查询订单数据 -->
	<!-- Order findById(Integer id) -->
	<select id="findById"
		resultMap="OrderEntityMap">
		select 
			*
		from
			t_order
		where
			id=#{id}
	</select>


开发对应的测试用例：

	@Test
	public void updateStatus() {
		Integer row=mapper.updateStatus(5, 500, "Tom", new Date());
		System.err.println(row);
	}
	
	@Test
	public void findById() {
		Order order=mapper.findById(5);
		System.err.println(order);
	}

“修改订单状态”的业务层：

规划异常：

	UpdateException
	OrderNotFoundException

在`IOrderService`中添加改变订单状态的抽象方法：

	void changeStatus(Integer oid, Integer status,String username);

在`OrderServiceImple`中：

为持久层的抽象方法提供私有实现：

	
实现接口中定义的抽象方法：

	public void changeStatus(Integer oid, Integer status,String username){
		// 使用oid查询订单数据
		// 判断结果是否为Null
		// 是： OrderNotFoundException
	
		// 更新订单状态
	}

代码实现如下：

	@Override
	public void changeStatus(Integer oid, Integer status, String username) {
		// 使用oid查询订单数据
		Order order=findById(oid);
		// 判断结果是否为Null
		if(order==null) {
			// 是： OrderNotFoundException
			throw new OrderNotFoundException("更新订单状态异常！订单数据不存在!");
		}
	
		// 更新订单状态
		updateStatus(oid, status, username, new Date());
	}

开发对应的测试用例：

	@Test
	public void changeStatus() {
		try {
			service.changeStatus(8, Status.CLOSED, "管理员");
		} catch (Exception e) {
			System.err.println(e.getClass().getName());
			System.err.println(e.getMessage());
		}
	}

需要在`IProductService`接口中声明一个增加商品库存的方法：

	void addNum(Integer pid,Integer num);

需要在`ProductServiceImpl`中实现该方法：

	@Override
	public void addNum(Integer pid, Integer num) {
		// 根据pid查询商品数据
		Product product=findById(pid);
		// 判断结果是否为null
		if(product==null) {
			// 是：ProductNotFoundException
			throw new ProductNotFoundException("减少商品库存数量异常！商品数据不存在！");
		}
		
		// 忽略商品下架

		// 从查询结果中获取当前库存量
		Integer oldNum=product.getNum();
		// 计算库存减少后的结果
		Integer newNum=oldNum+num;
		
		// 执行更新操作
		updateNum(newNum, pid);
	}


当订单超时后，`IOrderService`应该提供一个方法，执行关闭订单的操作：

	void close(Integer oid,List<OrderItem> orderItems,String username);

在`OrderServiceImpl`中实现该抽象方法：

	public void close(Integer oid, List<OrderItem> orderItems,String username){
		// 根据oid获取订单数据		
		// 判断结果是否为null
		// 是：OrderNotFoundException

		// 判断订单状态是否不为0
		// 是：return;

		// 修改订单状态 status->3

		// 归还库存
		// 遍历orderItems
		// -- 获取pid和num
		// -- 调用增加库存的方法 addNum(pid,num);
	}

代码实现如下：

	@Override
	public void close(Integer oid, List<OrderItem> orderItems, String username) {
		// 使用oid查询订单数据
		Order order=findById(oid);
		// 判断结果是否为Null
		if(order==null) {
			// 是： OrderNotFoundException
			throw new OrderNotFoundException("关闭订单异常！订单数据不存在!");
		}

		// 判断订单状态是否不为0
		if(!order.getStatus().equals(0)) {
			// 是：return;
			return;
		}

		// 修改订单状态 status->3
		changeStatus(oid, Status.CLOSED, username);

		// 归还库存
		// 遍历orderItems
		for(OrderItem item:orderItems) {
			// -- 调用增加库存的方法 addNum(pid,num);
			productService.addNum(item.getPid(), item.getNum());
		}
	};

并在`createOrder()`方法中补充处理超时未支付的代码：

	// 处理超时未支付		
	// 启动子线程，休眠15分钟
	// 在子线程醒来之后，执行关闭订单的操作
	new Thread(new Runnable() {
		@Override
		public void run() {
			System.err.println("子线程准备休眠...");
			try {
				Thread.sleep(30*1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.err.println("子线程启动，执行关闭订单操作...");
			// 调用关闭订单的方法
			close(order.getId(), orderItems, username);
		}
	}).start();

最后，在`OrderServiceTests`中对创建订单的整个功能进行测试：

	@Test
	public void createOrder() {
		try {
			Integer[] cids= {18,19};
			service.createOrder(2, cids, 1, "管理员");
		} catch (Exception e) {
			System.err.println(e.getClass().getName());
			System.err.println(e.getMessage());
		}
		try {
			Thread.sleep(32*1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

注意：测试用例会在主线程结束后以`System.exit()`结束当前程序(进程)，在休眠的其他子线程会被强制关闭，因此看不到超时归还库存的效果。需要在测试用例中让主线程多休眠几秒，保证子线程有时间苏醒和执行相关处理逻辑。

###78. 订单-创建-控制器层：

**(a) 统一异常处理**

	

**(b) 设计请求**

	请求路径：/orders/create
	请求参数：Integer aid, Integer[] cids,HttpSession session
	请求方式：POST
	相应数据：JsonResult<Void>

**(c) 处理请求**

创建`OrderController`，继承`BaseController`，添加以下方法：

	@Autowired
	IOrderService service;

	@PostMapping("create")
	public JsonResult<Void> createOrder(Integer aid, Integer[] cids,HttpSession session){
		Integer uid=getUidFromSession(session);
		String username=getUsernameFromSession(session);
		service.createOrder(aid,cids,uid,username);
		return new JsonResult<>(SUCCESS);
	}



###79. 订单-创建-前端界面：





### Spring AOP

#### 概念
	
AOP，指面向切面编程，Aspect Oriented Programming

切面：指的是哪些会被多个业务重复调用，但是和具体业务关系不大的模块，例如日志模块，性能统计模块，事务管理模块，安全验证模块等

Spring 为AOP提供了非常好的支持，可以通过简单的配置和注解实现AOP

#### 用途：

解耦：将与业务无关的通用性功能从业务代码中分离出来，使开发者仅需要关注业务相关的逻辑。

#### 如何使用：

需要在项目中添加`aspectj-tools`和`aspectjweaver`的依赖：

	<dependency>
	  <groupId>aspectj</groupId>
	  <artifactId>aspectj-tools</artifactId>
	  <version>1.0.6</version>
	</dependency>

	<dependency>
	  <groupId>org.aspectj</groupId>
	  <artifactId>aspectjweaver</artifactId>
	  <version>1.9.3</version>
	</dependency>

需要开发一个切面类`cn.tedu.store.aop.TimerAspect`，在类上添加2个必要的注解`@Aspect`和`@Component`:

	@Aspect
	@Component
	public class TimerAspect {
	
	}


在类中添加切面方法：

方法的参数列表中必须添加参数`ProceedingJoinPoint`，它代表了目标方法的句柄：

	@Around("execution(* cn.tedu.store.service.impl.*.*(..))")
	public Object a(ProceedingJoinPoint pjp) throws Throwable {
		// 记录开始时间
		long st=System.currentTimeMillis();
		
		//调用目标方法
		Object result=pjp.proceed();
		
		// 记录结束时间
		long et=System.currentTimeMillis();
		// 输出耗时
		System.err.println(pjp.getSignature().getName()+"-> 耗时："+(et-st)+"ms.");
		
		return result;
	}

`pjp.proceed()`代表调用了目标方法，该目标方法可能是有返回值的方法，对于这类方法，应该接收方法的返回值，并在切面结束时返回该返回值。

`pjp.proceed()`调用目标方法时，可能抛出异常`Throwable`，如果在切面方法中不需要对异常进行处理，可直接在签名中声明抛出。

需要在切面方法前添加`@Around`注解，指明该切面方法是在目标方法调用前和调用后都有逻辑执行，对应的也可以添加`@Before`或`@After`，但是一般没有必要。

在`@Around`注解后需要指明当前切面方法注入的目标位置，`@Around("execution(* cn.tedu.store.service.impl.*.*(..))")`代表业务层所有的方法都被注入。


