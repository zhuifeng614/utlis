package cn.tedu.spring;

public class StudentDao2 extends StudentDao {

	public void reg() {
		System.out.println("StudentDao2.reg()");
	}
	
}
