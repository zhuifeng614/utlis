package cn.tedu.spring;

public class AdminDao {
	
	public String url;

	public AdminDao(String url) {
		super();
		this.url = url;
	}

}
