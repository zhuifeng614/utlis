package cn.tedu.spring;

public class StudentDao {
	
	public void reg() {
		System.out.println("StudentDao.reg()");
	}

}
