package cn.tedu.spring;

public class UserServlet {

	public UserDao userDao;

	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}
	
}
