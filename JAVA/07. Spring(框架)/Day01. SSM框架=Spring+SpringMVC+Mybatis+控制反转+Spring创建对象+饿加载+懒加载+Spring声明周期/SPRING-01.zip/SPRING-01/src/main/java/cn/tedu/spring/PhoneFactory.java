package cn.tedu.spring;

public class PhoneFactory {

	public Phone newInstance() {
		return new Phone("HuaWei");
	}
	
}
