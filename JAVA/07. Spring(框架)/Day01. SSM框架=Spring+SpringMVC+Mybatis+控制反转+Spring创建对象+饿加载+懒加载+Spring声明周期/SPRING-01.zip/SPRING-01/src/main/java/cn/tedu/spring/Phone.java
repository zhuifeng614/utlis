package cn.tedu.spring;

public class Phone {

	public Phone(String name) {
		
	}
	
}
